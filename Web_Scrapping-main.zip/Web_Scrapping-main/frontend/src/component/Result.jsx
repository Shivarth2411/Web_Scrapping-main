import React from 'react'

function Result({url}) {
  return (
    <div>
        
    </div>
  )
}

export default Result;